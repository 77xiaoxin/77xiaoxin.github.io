package com.sep10.framework.dao;

import javax.annotation.Resource;

import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

@Repository("userDao")
public class UserDao {

	@Resource(name = "jdbcTemplate")
	private JdbcTemplate jdbcTemplate;
	
	public int login(String userName, String password) {
		String sql = "select count(*) from t_user where username = ? and password = ?";
		return this.jdbcTemplate.queryForInt(sql, new Object[]{userName, password});
	}
}
