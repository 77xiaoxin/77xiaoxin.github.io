package com.sep10.framework.taskjob;

import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

@Component
public class TaskJob {

	@Scheduled(cron="0/5 * * * * ?")
	public void sendCollect(){
		System.out.println("Hello World!");
	}
}
