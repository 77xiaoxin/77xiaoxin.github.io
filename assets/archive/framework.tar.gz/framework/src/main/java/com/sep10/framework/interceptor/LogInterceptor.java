package com.sep10.framework.interceptor;

import javax.servlet.http.HttpServletRequest;

import org.apache.log4j.Logger;
import org.aspectj.lang.annotation.After;
import org.aspectj.lang.annotation.Aspect;
import org.springframework.stereotype.Component;

@Component
@Aspect
public class LogInterceptor {
	
	private Logger log = Logger.getLogger("request");
	
	@After(value = "@annotation(org.springframework.web.bind.annotation.RequestMapping) && args(request)")
    public void after(HttpServletRequest request) {
		StringBuffer sb = new StringBuffer();
		sb.append((request.getAttribute("username") == null ? "-" : request.getAttribute("username").toString()) + "\t");
		sb.append((request.getRequestedSessionId() == null ? "-" : request.getRequestedSessionId()) + "\t");
		sb.append((request.getRemoteAddr() == null ? "-" : request.getRemoteAddr()) + "\t");
		sb.append((request.getMethod() == null ? "-" : request.getMethod()) + "\t");
		sb.append((request.getRequestURL() == null ? "-" : request.getRequestURL()) + "\t");
		sb.append((request.getContentType() == null ? "-" : request.getContentType()) + "\t");
		sb.append((request.getHeader("referer") == null ? "-" : request.getHeader("referer")) + "\t");
		sb.append((request.getHeader("host") == null ? "-" : request.getHeader("host")) + "\t");
		sb.append(request.getHeader("user-agent") == null ? "-" : request.getHeader("user-agent"));
		log.info(sb.toString());
    }
}
