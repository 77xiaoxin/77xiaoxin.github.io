package com.sep10.framework.interceptor;

import javax.servlet.http.HttpServletRequest;

import org.aspectj.lang.annotation.After;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Before;
import org.springframework.stereotype.Component;

@Component
@Aspect
public class LogInterceptor {
	
	@Before(value = "@annotation(org.springframework.web.bind.annotation.RequestMapping) && args(request)")
	public void before(HttpServletRequest request) {
		System.out.println(request);
		System.out.println("before method");
	}

	@After(value = "@annotation(org.springframework.web.bind.annotation.RequestMapping) && args(request)")
    public void after(HttpServletRequest request) {
		System.out.println("getAuthType: " + request.getAuthType());
		System.out.println("getCharacterEncoding: " + request.getCharacterEncoding());
		System.out.println("getContentLength: " + request.getContentLength());
		System.out.println("getContentType: " + request.getContentType());
		System.out.println("getContextPath: " + request.getContextPath());
		System.out.println("getLocalAddr: " + request.getLocalAddr());
		System.out.println("getLocalName: " + request.getLocalName());
		System.out.println("getLocalPort: " + request.getLocalPort());
		System.out.println("getMethod: " + request.getMethod());
		System.out.println("getPathInfo: " + request.getPathInfo());
		System.out.println("getPathTranslated: " + request.getPathTranslated());
		System.out.println("getProtocol: " + request.getProtocol());
		System.out.println("getQueryString: " + request.getQueryString());
		System.out.println("getRemoteAddr: " + request.getRemoteAddr());
		System.out.println("getRemoteHost: " + request.getRemoteHost());
		System.out.println("getRemotePort: " + request.getRemotePort());
		System.out.println("getRemoteUser: " + request.getRemoteUser());
		System.out.println("getRequestedSessionId: " + request.getRequestedSessionId());
		System.out.println("getRequestURI: " + request.getRequestURI());
		System.out.println("getScheme: " + request.getScheme());
		System.out.println("getServerName: " + request.getServerName());
		System.out.println("getServerPort: " + request.getServerPort());
		System.out.println("getServletPath: " + request.getServletPath());
		System.out.println("getLocale: " + request.getLocale());
		System.out.println("getUserPrincipal: " + request.getUserPrincipal());
		System.out.println("getRequestURL: " + request.getRequestURL());
    }
}
