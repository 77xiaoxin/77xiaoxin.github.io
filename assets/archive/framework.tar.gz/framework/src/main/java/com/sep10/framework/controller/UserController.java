package com.sep10.framework.controller;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

import com.sep10.framework.service.UserService;


@Controller
public class UserController {

	@Resource(name = "userService")
	private UserService userService;
	
	@RequestMapping(value = "/login")
	public String login(HttpServletRequest request) {
		String userName = request.getParameter("username");
		String password = request.getParameter("password");
		int result = this.userService.login(userName, password);
		if (result > 0) {
			return "success";
		} else {
			return "error";
		}
	}
}
