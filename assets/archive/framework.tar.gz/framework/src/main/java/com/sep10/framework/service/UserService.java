package com.sep10.framework.service;

import javax.annotation.Resource;

import org.springframework.stereotype.Service;

import com.sep10.framework.dao.UserDao;


@Service("userService")
public class UserService {

	@Resource(name = "userDao")
	private UserDao userDao;
	
	public int login(String userName, String password) {
		return this.userDao.login(userName, password);
	}
}
